#Pydroid run pygame
# SUPER PLATEFORME V17 CORRIGEE - ENNEMIS TIREURS / moteur 30 FPS
import pygame, math, random, json, os, sys, asyncio
pygame.init()
W,H=960,540
# Android: use actual fullscreen display, avoiding software SCALED mode.
screen=pygame.display.set_mode((W,H))
native_scale=False
canvas=pygame.Surface((W,H))
clock=pygame.time.Clock()
font=pygame.font.Font(None,32); small=pygame.font.Font(None,25); big=pygame.font.Font(None,70)
SAVE=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'super_plateforme_v12_save.json')
COLORS=[((109,199,246),(62,169,100),(114,76,48)),((255,192,116),(211,145,68),(158,94,52)),((136,204,250),(188,233,250),(83,141,183)),((46,67,105),(61,104,140),(64,72,105)),((97,75,111),(111,87,104),(83,59,76))]
NAMES=['FORET','DESERT','NEIGE','GROTTE','CHATEAU']
ASSETS=os.path.join(os.path.dirname(os.path.abspath(__file__)),'assets')
def load_img(name,size=None):
    try:
        image=pygame.image.load(os.path.join(ASSETS,name))
        image=image.convert() if name.lower().endswith('.jpg') else image.convert_alpha()
        return pygame.transform.smoothscale(image,size) if size else image
    except Exception:
        return None
backgrounds=[load_img('background_%d.png'%i,(W,H)) for i in range(5)]
# Small pre-rendered sprites: never resize or flip during gameplay.
hero_frames={k:load_img('hero_'+k+'.png',(45,56)) for k in ('idle','run0','run1','run2','jump','fall')}
hero_flipped={k:pygame.transform.flip(img,True,False) if img else None for k,img in hero_frames.items()}
hero_big={k:load_img('hero_'+k+'.png',(57,77)) for k in ('idle','run0','run1','run2','jump','fall')}
hero_big_flipped={k:pygame.transform.flip(img,True,False) if img else None for k,img in hero_big.items()}
enemy_sprites=[load_img('enemy_%d.png'%i,(44,44)) for i in range(5)]
# Animations de monstres mises en cache (pas de transformation en jeu)
enemy_left=[pygame.transform.flip(img,True,False) if img else None for img in enemy_sprites]
# Halo discret prepare une seule fois
halo=pygame.Surface((92,92),pygame.SRCALPHA)
for rad,alpha in [(44,13),(33,19),(23,24)]:
    pygame.draw.circle(halo,(255,225,130,alpha),(46,46),rad)


LEVEL_END=3600
left=pygame.Rect(22,427,90,83); right=pygame.Rect(124,427,90,83); jump=pygame.Rect(843,417,95,93)
fire_btn=pygame.Rect(734,428,84,80)
pause_btn=pygame.Rect(892,12,54,50)
menu_buttons=[pygame.Rect(340,215+i*68,280,55) for i in range(4)]
modal_buttons=[pygame.Rect(337,250+i*66,286,55) for i in range(3)]
control_draw=[]
for r,symbol in [(left,'<'),(right,'>'),(jump,'^'),(fire_btn,'F')]:
    overlay=pygame.Surface(r.size,pygame.SRCALPHA)
    pygame.draw.rect(overlay,(17,42,57,75),overlay.get_rect(),border_radius=19)
    control_draw.append((r,symbol,overlay))
touches={}; mouse=False; prev_jump=False; frame=0; camera=0
sound=True
try:
    pygame.mixer.init()
    def tone(freq,duration=.09):
        import array
        rate=22050; n=int(rate*duration)
        data=array.array('h',(int(2600*math.sin(2*math.pi*freq*i/rate)*(1-i/n)) for i in range(n)))
        return pygame.mixer.Sound(buffer=data.tobytes())
    sounds={'jump':tone(480),'coin':tone(920),'hit':tone(180,.18),'win':tone(680,.22)}
except Exception: sounds={}
# Music is optional and separate from sound effects.
try:
    pygame.mixer.music.load(os.path.join(ASSETS,'music.wav'))
    pygame.mixer.music.set_volume(0.20)
    if sound: pygame.mixer.music.play(-1)
except Exception:
    pass
def play(k):
    if sound and k in sounds:
        try: sounds[k].play()
        except Exception: pass

def save():
    try:
        with open(SAVE,'w') as f: json.dump({'level':level,'score':score,'best':best,'sound':sound},f)
    except Exception: pass
try:
    with open(SAVE) as f: stored=json.load(f)
except Exception: stored={}
best=int(stored.get('best',0)); sound=bool(stored.get('sound',True))
try:
    if sound and not pygame.mixer.music.get_busy(): pygame.mixer.music.play(-1)
    elif not sound: pygame.mixer.music.stop()
except Exception: pass

def text(s,x,y,f=font,color=(255,255,255),center=False):
    a=f.render(str(s),True,color); canvas.blit(a,a.get_rect(center=(x,y)) if center else (x,y))
def rect(r,c,rad=0): pygame.draw.rect(canvas,c,r,border_radius=rad)
def circle(c,x,y,r): pygame.draw.circle(canvas,c,(int(x),int(y)),int(r))
def button(r,label,selected=False):
    rect(r,(32,65,81) if not selected else (39,146,91),14)
    pygame.draw.rect(canvas,(219,245,243),r,2,border_radius=14)
    text(label,r.centerx,r.centery,font,center=True)
def init_level(n):
    global level,player,vy,grounded,platforms,coins,enemies,hearts,stars,invincible,shield,boost,boss,boss_hp,boss_cooldown,camera,checkpoint,movers,spikes,secret_coins,projectiles,boss_timer,secret_found,mystery_blocks,brick_blocks,coin_pops,brick_bits,mushrooms,power_timer,star_timer,flowers,fireballs,fire_timer,fire_cooldown,enemy_shots
    level=n; player=pygame.Rect(70,410,37,53); vy=0; grounded=False; camera=0; checkpoint=70
    invincible=0; shield=0; boost=0; boss_cooldown=0; secret_found=0
    coin_pops=[];brick_bits=[];power_timer=0;star_timer=0;fire_timer=0;fire_cooldown=0;fireballs=[]
    flowers=[{'x':x,'y':y,'taken':False} for x,y in [(590,320),(1770,235),(2790,280)]]
    mushrooms=[{'x':x,'y':y,'taken':False} for x,y in [(1010,415),(2300,415),(3260,415)]]
    platforms=[]
    # Blocs mysteres et briques solides : places hors des zones de depart.
    mystery_blocks=[]
    for bx,by in [(490,245),(1150,250),(1850,235),(2550,260),(3200,225)]:
        mystery_blocks.append({'rect':pygame.Rect(bx,by,40,40),'used':False,'flash':0})
    brick_blocks=[pygame.Rect(bx,by,40,40) for bx,by in [(530,245),(1190,250),(1890,235),(2590,260),(3240,225)]]
    platforms.extend(brick_blocks)
    # Segmented ground: holes in each world
    holes=[(690,805),(1420,1545),(2130,2250),(3010,3130)]
    if n>=2: holes.append((1750,1870))
    starts=[0]+[b for a,b in sorted(holes)]
    ends=[a for a,b in sorted(holes)]+[LEVEL_END+120]
    for a,b in zip(starts,ends):
        if b>a: platforms.append(pygame.Rect(a,486,b-a,54))
    platforms.extend(b['rect'] for b in mystery_blocks)
    for i,x in enumerate(range(220,LEVEL_END-140,235)):
        y=[391,315,355,275,370][i%5]
        platforms.append(pygame.Rect(x,y,140,20))
    coins=[{'x':x,'y':y,'taken':False} for x,y in [(310,348),(455,275),(570,315),(880,350),(1050,235),(1220,325),(1380,270),(1600,335),(1780,225),(1960,330),(2150,265),(2400,345),(2590,320),(2810,275),(2980,320),(3200,265),(3410,345)]]
    enemies=[{'x':x,'start':x,'dir':1,'alive':True,'y':448,'kind':i%3,'phase':i*.9,'speed':1.0+(i%3)*.22} for i,x in enumerate([515,1000,1300,1700,2030,2450,2860,3320])]
    hearts=[{'x':1140,'y':270,'taken':False}]
    stars=[{'x':1870,'y':245,'taken':False}]
    # Secret coins are revealed only when the hero comes close.
    secret_coins=[{'x':x,'y':y,'taken':False} for x,y in [(735,175),(1510,165),(3070,170)]]
    # Moving platforms move horizontally; the player is carried while standing on them.
    movers=[{'r':pygame.Rect(x,y,115,19),'base':x,'phase':i*1.8,'oldx':x,'oldy':y,'basey':y,'vertical':i%2==1} for i,(x,y) in enumerate([(780,330),(1500,285),(2240,325),(3060,300)])]
    spikes=[pygame.Rect(x,466,65,20) for x in (1100,1940,2710,3390)]
    projectiles=[];enemy_shots=[];boss_timer=0
    boss=pygame.Rect(3350,413,75,73) if n==4 else None
    boss_hp=3

def new_game():
    global score,lives,state,prev_jump
    score=0; lives=3; prev_jump=False; init_level(0); state='play'; save()
def continue_game():
    global score,lives,state,prev_jump
    score=int(stored.get('score',0)); lives=3
    prev_jump=False; init_level(max(0,min(4,int(stored.get('level',0))))); state='play'
def lose_life():
    global lives,state,invincible,vy,power_timer,fire_timer
    if invincible>0:return
    if shield>0:
        globals()['shield']=0; invincible=80;play('hit');return
    if power_timer>0:
        power_timer=0;fire_timer=0
        player.bottom=player.bottom;player.height=53
        invincible=90;play('hit');return
    lives-=1;play('hit')
    if lives<=0:state='gameover';save();return
    player.x=checkpoint;player.y=400;vy=0;invincible=110

def convert(pos):
    sw,sh=screen.get_size()
    return int(pos[0]*W/max(sw,1)),int(pos[1]*H/max(sh,1))
def finger(ev):
    return max(0,min(W-1,int(ev.x*W))),max(0,min(H-1,int(ev.y*H)))
def get_buttons():
    a=b=c=False
    for p in touches.values():
        a |= left.collidepoint(p); b |= right.collidepoint(p); c |= jump.collidepoint(p)
    keys=pygame.key.get_pressed()
    return a or keys[pygame.K_LEFT],b or keys[pygame.K_RIGHT],c or keys[pygame.K_SPACE]
def render_sky_once():
    bg,grass,soil=COLORS[level]
    canvas.fill(bg)
    if backgrounds[level]:
        canvas.blit(backgrounds[level],(0,0))
        # Light atmospheric veil preserves foreground readability.
        veil=pygame.Surface((W,H),pygame.SRCALPHA)
        veil.fill((bg[0],bg[1],bg[2],95))
        canvas.blit(veil,(0,0))
    if level==4:
        for i in range(0,1000,130):
            pygame.draw.polygon(canvas,(72,61,92),[(i-100,380),(i+70,150),(i+210,380)])
    elif level==3:
        for i in range(0,1100,160):
            pygame.draw.polygon(canvas,(34,50,83),[(i,0),(i+85,115),(i+160,0)])
        for i in range(0,1100,180):
            pygame.draw.polygon(canvas,(85,194,241),[(i+30,455),(i+66,390),(i+105,455)])
    else:
        circle((255,232,130),825,93,42)
        for j in range(4):
            x=int((j*305-frame*(.14 if level!=2 else .25))%1230)-100
            for dx,dy,r in [(0,10,25),(30,0,34),(64,11,26)]:circle((245,250,255),x+dx,95+dy+j%2*25,r)
        for j in range(7):
            x=j*205-int(camera*.17)%205
            pygame.draw.ellipse(canvas,grass,(x-150,350+(j%2)*30,350,260))
        if level==2:
            for j in range(8):
                x=j*170-int(camera*.25)%170
                pygame.draw.polygon(canvas,(240,249,255),[(x,445),(x+75,300),(x+150,445)])
    # Decorative plants behind terrain
    if level in (0,1,2):
        for wx in range(90,LEVEL_END,280):
            x=wx-camera*.75
            if -80<x<W+80:
                if level==1:
                    rect((x-5,390,11,90),(72,139,67),5)
                    for dy in (410,440):pygame.draw.ellipse(canvas,(72,139,67),(x-24,dy,50,14))
                else:
                    rect((x-9,388,18,100),(110,77,54),5)
                    for ox,oy,r in [(-22,394,30),(15,385,34),(0,363,32)]:circle((49,156,90) if level==0 else (237,246,255),x+ox,oy,r)
    # V12: details de paysage calcules UNE SEULE FOIS (aucun cout par frame).
    rng=random.Random(1100+level)
    if level==0:  # Foret : bosquets, lucioles et fleurs lointaines
        for _ in range(65):
            x=rng.randrange(0,W); y=rng.randrange(405,510)
            pygame.draw.circle(canvas,(242,221,116),(x,y),rng.choice((1,2,2)))
        for x in range(35,W,115):
            pygame.draw.ellipse(canvas,(38,135,86),(x,425,95,70))
            pygame.draw.ellipse(canvas,(49,159,95),(x+18,418,68,58))
    elif level==1:  # Desert : strates de sable et pierres
        for x in range(0,W,7):
            y=472+int(6*math.sin(x*.022))
            pygame.draw.line(canvas,(235,166,93),(x,y),(x+4,y),2)
        for _ in range(55):
            x=rng.randrange(W); y=rng.randrange(435,515)
            pygame.draw.ellipse(canvas,(170,105,61),(x,y,7,3))
    elif level==2:  # Neige : cristaux immobiles au loin
        for _ in range(95):
            x=rng.randrange(W); y=rng.randrange(55,480)
            pygame.draw.circle(canvas,(245,252,255),(x,y),rng.choice((1,1,2)))
    elif level==3:  # Grotte : mineraux lumineux
        for _ in range(42):
            x=rng.randrange(W); y=rng.randrange(180,470)
            pygame.draw.polygon(canvas,(81,161,183),[(x,y),(x+5,y-12),(x+10,y)])
    else:  # Chateau : fenetres dans les tours lointaines
        for x in range(45,W,145):
            pygame.draw.rect(canvas,(66,57,93),(x,345,70,150),border_radius=8)
            for y in (375,418):
                pygame.draw.rect(canvas,(237,186,101),(x+26,y,17,27),border_radius=7)

# Pre-render scenery once per world instead of hundreds of draw calls per frame.
sky_cache=[]
for _world in range(5):
    level=_world
    camera=0
    frame=0
    render_sky_once()
    sky_cache.append(canvas.copy())
level=0

def sky():
    canvas.blit(sky_cache[level],(0,0))

# V12: tuiles de sol avec ombrage precalcule, sans generation en jeu.
terrain_tiles=[]
for world,(sky_col,grass_col,soil_col) in enumerate(COLORS):
    tile=pygame.Surface((64,54),pygame.SRCALPHA)
    tile.fill(soil_col)
    pygame.draw.rect(tile,tuple(min(255,c+23) for c in grass_col),(0,0,64,8))
    pygame.draw.line(tile,(238,250,170) if world in (0,2) else (246,218,160),(0,1),(64,1),2)
    rng=random.Random(300+world)
    for _ in range(12):
        xx=rng.randrange(3,61); yy=rng.randrange(13,51)
        pygame.draw.circle(tile,tuple(min(255,c+28) for c in soil_col),(xx,yy),rng.choice((1,2,2)))
    pygame.draw.line(tile,tuple(max(0,c-19) for c in soil_col),(0,52),(64,52),2)
    terrain_tiles.append(load_img('terrain_%d.png'%world,(64,54)) or tile)

hud_band=pygame.Surface((W,51),pygame.SRCALPHA)
hud_band.fill((235,248,252,60))

def draw_world():
    bg,grass,soil=COLORS[level]
    sky()
    for p in platforms:
        r=p.move(-int(camera),0)
        if r.right<0 or r.left>W:continue
        rect(r,soil,3)
        tile=terrain_tiles[level]
        clip_old=canvas.get_clip()
        canvas.set_clip(r.clip(pygame.Rect(0,0,W,H)))
        for tx in range(r.x,r.right,64):
            canvas.blit(tile,(tx,r.y))
        canvas.set_clip(clip_old)
        pygame.draw.line(canvas,(198,245,134) if level==0 else (245,244,213),(r.x,r.y),(r.right,r.y),2)
    # Blocs mysteres : dessin simple, sans image redimensionnee par frame.
    for block in mystery_blocks:
        r=block['rect'].move(-int(camera),0)
        if r.right<0 or r.left>W:continue
        col=(151,135,109) if block['used'] else (248,175,41)
        pygame.draw.rect(canvas,(105,68,43),r.move(0,3),border_radius=5)
        pygame.draw.rect(canvas,col,r,border_radius=5)
        pygame.draw.rect(canvas,(255,225,125) if not block['used'] else (190,174,143),r,3,border_radius=5)
        if not block['used']:
            text('?',r.centerx,r.centery-1,font,(125,73,33),True)
        for dx in (7,33):
            for dy in (7,33):circle((117,79,51),r.x+dx,r.y+dy,2)
    for brick in brick_blocks:
        r=brick.move(-int(camera),0)
        if r.right<0 or r.left>W:continue
        pygame.draw.rect(canvas,(178,92,53),r,border_radius=3)
        pygame.draw.rect(canvas,(233,144,79),r,3,border_radius=3)
        pygame.draw.line(canvas,(105,65,46),(r.x,r.y+20),(r.right,r.y+20),3)
        pygame.draw.line(canvas,(105,65,46),(r.centerx,r.y),(r.centerx,r.y+20),3)
        pygame.draw.line(canvas,(105,65,46),(r.x+10,r.y+20),(r.x+10,r.bottom),3)
    # Animations legeres : aucune nouvelle image a charger par frame.
    for pop in coin_pops:
        x=int(pop['x']-camera); y=int(pop['y']-pop['age']*2.7+0.10*pop['age']**2)
        rw=max(3,int(12*abs(math.cos(pop['age']*.26))))
        pygame.draw.ellipse(canvas,(180,103,23),(x-rw-2,y-15,rw*2+4,30))
        pygame.draw.ellipse(canvas,(255,217,42),(x-rw,y-14,rw*2,28))
        circle((255,255,210),x-2,y-6,3)
        if pop['age']<18:
            for a in range(4):
                ang=a*math.pi/2+pop['age']*.15
                circle((255,245,150),x+math.cos(ang)*(15+pop['age']),y+math.sin(ang)*(12+pop['age']),2)
    for bit in brick_bits:
        x=int(bit['x']-camera); y=int(bit['y'])
        if -10<x<W+10:rect((x,y,7,7),(214,124,68),1)
    for item in mushrooms:
        if item['taken']:continue
        x=int(item['x']-camera);y=int(item['y'])
        if -35<x<W+35:
            rect((x-10,y-2,20,17),(249,227,189),5)
            pygame.draw.ellipse(canvas,(224,62,61),(x-17,y-19,34,21))
            circle((255,255,240),x-7,y-12,5);circle((255,255,240),x+9,y-12,4)
    # Fleurs de feu : bonus anime et leger.
    for flower in flowers:
        if flower['taken']:continue
        x=int(flower['x']-camera);y=int(flower['y']+math.sin(frame*.09)*3)
        if -30<x<W+30:
            circle((246,168,37),x,y,17)
            for ox,oy in ((-12,0),(12,0),(0,-12),(0,12)):
                circle((255,91,49),x+ox,y+oy,9)
            circle((255,246,129),x,y,9)
    for ball in fireballs:
        x=int(ball['x']-camera);y=int(ball['y'])
        if -20<x<W+20:
            circle((255,117,33),x,y,11);circle((255,233,87),x,y,6)
    for c in coins + [q for q in secret_coins if abs(player.centerx-q['x'])<150]:
        if c['taken']:continue
        x=c['x']-camera;y=c['y']+math.sin(frame*.08+c['x'])*4
        if -30<x<W+30:
            rw=max(4,int(13*abs(math.cos(frame*.065+c['x']))))
            pygame.draw.ellipse(canvas,(183,110,23),(x-rw-2,y-17,rw*2+4,34))
            pygame.draw.ellipse(canvas,(255,207,38),(x-rw,y-16,rw*2,32))
            circle((255,247,176),x-3,y-7,3)
    for group,symbol,col in [(hearts,'+', (247,78,106)),(stars,'*',(255,224,63))]:
        for item in group:
            if item['taken']:continue
            x=item['x']-camera;y=item['y']+math.sin(frame*.07)*6
            circle(col,x,y,17);text(symbol,x,y,small,(255,255,255),True)
    for m in movers:
        r=m['r'].move(-int(camera),0)
        if -140<r.x<W:
            rect(r,(78,104,157),7);rect((r.x,r.y,r.w,7),(129,223,233),4)
            for bx in (r.x+14,r.right-14):circle((236,242,250),bx,r.y+13,3)
    for spike in spikes:
        sx=spike.x-camera
        if -80<sx<W:
            for off in range(0,spike.w,13):
                pygame.draw.polygon(canvas,(195,210,224),[(sx+off,spike.bottom),(sx+off+7,spike.top),(sx+off+14,spike.bottom)])
    for pr in projectiles:
        x=pr['x']-camera;y=pr['y']
        if -20<x<W+20:circle((255,118,42),x,y,11);circle((255,219,100),x-3,y-3,5)
    for shot in enemy_shots:
        sx=int(shot['x']-camera);sy=int(shot['y'])
        if -12<sx<W+12:
            circle((255,90,50),sx,sy,8)
            circle((255,230,120),sx-2,sy-2,4)
    for e in enemies:
        if not e['alive']:continue
        x=int(e['x']-camera);y=e['y'] + (int(math.sin(frame*.12+e['phase'])*16)-24 if e['kind']==2 else 0)
        if x < -60 or x > W+60:continue
        if enemy_sprites[level]:
            # Petit rebond anime et orientation du monstre
            bounce=int(abs(math.sin(frame*.13+e['phase']))*3)
            sprite=enemy_sprites[level] if e['dir']>0 else enemy_left[level]
            canvas.blit(sprite,(x-3,y-5-bounce))
        else:
            pygame.draw.ellipse(canvas,(94,44,150),(x,y,39,38))
    if boss and boss_hp>0:
        x=boss.x-camera;y=boss.y
        # Boss anime, avec aura et indication des points de vie
        canvas.blit(halo,(int(x-8),int(y-12)))
        boss_color=(145,57,72) if boss_cooldown%10<5 else (255,145,105)
        rect((x,y,boss.w,boss.h),boss_color,16)
        circle((255,223,89),x+23,y+25,11);circle((255,223,89),x+53,y+25,11)
        pygame.draw.polygon(canvas,(255,215,94),[(x+10,y+7),(x+20,y-18),(x+35,y+7)])
        pygame.draw.polygon(canvas,(255,215,94),[(x+44,y+7),(x+59,y-18),(x+69,y+7)])
        text('BOSS '+str(boss_hp),x+37,y-44,small,(255,240,225),True)
    # End flag
    fx=LEVEL_END-90-camera
    rect((fx,335,9,151),(35,55,65))
    pygame.draw.polygon(canvas,(255,220,55),[(fx+9,337),(fx+68,360),(fx+9,384)])
    # V12 : ombre de contact et lueur de bouclier.
    if invincible%10<5:
        px=int(player.centerx-camera)
        py=int(player.bottom)
        if 0<=px<W and py<H:
            pygame.draw.ellipse(canvas,(45,90,73),(px-15,py-3,30,6))
        if shield>0 or power_timer>0 or star_timer>0:
            pygame.draw.circle(canvas,(255,227,85) if star_timer>0 else (150,232,251),(px,int(player.centery)),34,2)
    # Hero sprite: flip with direction, subtle run animation.
    if invincible%10<5:
        x=int(player.x-camera);y=player.y
        step=abs(math.sin(frame*.23))*3 if moving and grounded else 0
        if hero_frames['idle']:
            pose=('jump' if vy < -1 else 'fall' if vy > 2 else 'run'+str((frame//5)%3) if moving and grounded else 'idle')
            big_hero=power_timer>0
            frames=(hero_big if facing>0 else hero_big_flipped) if big_hero else (hero_frames if facing>0 else hero_flipped)
            sprite=frames[pose]
            if sprite:canvas.blit(sprite,(x-10 if big_hero else x-4,y-5))
        else:
            rect((x,y,player.w,player.h),(225,60,65),8)
    # translucent controls (cached)
    for r,s,overlay in control_draw:
        canvas.blit(overlay,r.topleft);text(s,r.centerx,r.centery,font,center=True)
    canvas.blit(hud_band,(0,0))
    text('NIVEAU %s/5 - %s'%(level+1,NAMES[level]),18,14,small,(24,52,70))
    text('PIECES : '+str(score),340,14,small,(24,52,70))
    text('VIES : '+str(lives),580,14,small,(24,52,70))
    text('MONDE '+str(int(player.x/600)+1)+'/6',760,14,small,(24,52,70))
    if fire_timer>0:text('FEU '+str(fire_timer//30)+'s',665,48,small,(180,57,28))
    elif power_timer>0:text('SUPER '+str(power_timer//30)+'s',665,48,small,(24,52,70))
    if shield>0:text('BOUCLIER',700,14,small,(24,52,70))
    elif boost>0:text('VITESSE',700,14,small,(24,52,70))
    if secret_found:
        text('SECRETS : '+str(secret_found),760,48,small,(24,52,70))
    button(pause_btn,'II')

def draw_menu():
    canvas.fill((87,177,218))
    for i in range(9):
        pygame.draw.ellipse(canvas,(63+i%3*13,157+i%3*10,115),(i*135-70,355+i%2*30,290,240))
    circle((255,222,94),820,95,55)
    text('SUPER PLATEFORME',W//2,87,big,(255,237,110),True)
    text('VERSION WEB V17',W//2,148,font,(255,255,255),True)
    for r,label in zip(menu_buttons,['JOUER','CONTINUER','OPTIONS','MEILLEUR SCORE']):button(r,label)
    text('Record : '+str(best),480,503,small,center=True)

modal_shade=pygame.Surface((W,H),pygame.SRCALPHA)
modal_shade.fill((13,24,40,165))
def draw_modal(title,labels):
    canvas.blit(modal_shade,(0,0))
    rect((260,112,440,352),(235,246,252),22)
    text(title,480,173,big,(35,73,89),True)
    for r,label in zip(modal_buttons,labels):button(r,label)

def tap(pos):
    global state,sound,best,stored
    if state=='menu':
        for i,r in enumerate(menu_buttons):
            if r.collidepoint(pos):
                if i==0:new_game()
                elif i==1:continue_game()
                elif i==2:state='options'
                else:state='scores'
                return
    elif state=='play':
        if pause_btn.collidepoint(pos):state='pause';save()
    elif state=='pause':
        if modal_buttons[0].collidepoint(pos):state='play'
        elif modal_buttons[1].collidepoint(pos):init_level(level);state='play'
        elif modal_buttons[2].collidepoint(pos):state='menu';save()
    elif state=='options':
        if modal_buttons[0].collidepoint(pos):
            sound=not sound
            try:
                if sound: pygame.mixer.music.play(-1)
                else: pygame.mixer.music.stop()
            except Exception: pass
            save()
        elif modal_buttons[1].collidepoint(pos):state='menu'
    elif state=='scores':
        if modal_buttons[0].collidepoint(pos):state='menu'
    elif state in ('gameover','victory'):
        if modal_buttons[0].collidepoint(pos):new_game()
        elif modal_buttons[1].collidepoint(pos):state='menu'

level=0;score=0;lives=3;state='menu';facing=1;moving=False
init_level(0)
running=True
# Browser-side bridge: read touch commands without depending on SDL mouse focus.
try:
 import platform as web_platform
 web_window=web_platform.window
except Exception:
 web_window=None
web_held=set()
def browser_input():
 global web_held
 if web_window is None:return
 try:
  command=str(web_window.spInputMessage)
  if command:
   web_window.spInputMessage=''
   if command=='play':new_game()
   elif command=='continue':continue_game()
   elif command=='options':state_set('options')
   elif command=='scores':state_set('scores')
   elif command=='pause':tap(pause_btn.center) if state=='play' else tap(modal_buttons[0].center)
  held=str(web_window.spHeldKeys)
  web_held=set(held.split(',')) if held else set()
  web_window.spGameState=state
 except Exception:pass
def state_set(value):
 global state
 state=value
display_size=screen.get_size()
fps_label=None
async def main():
 global running,frame,mouse,prev_jump,state,facing,moving,camera,level,score,best,lives,shield,boost,star_timer,invincible,power_timer,fire_timer,fire_cooldown,vy,checkpoint,boss_timer,boss_cooldown,boss_hp,secret_found,fps_label,grounded
 while running:
    frame+=1
    browser_input()
    for ev in pygame.event.get():
        if ev.type==pygame.QUIT:running=False
        elif ev.type==pygame.KEYDOWN:
            if state=='menu':
                if ev.key in (pygame.K_RETURN,pygame.K_KP_ENTER,pygame.K_j,pygame.K_1):tap(menu_buttons[0].center)
                elif ev.key in (pygame.K_c,pygame.K_2):tap(menu_buttons[1].center)
                elif ev.key in (pygame.K_o,pygame.K_3):tap(menu_buttons[2].center)
                elif ev.key in (pygame.K_s,pygame.K_4):tap(menu_buttons[3].center)
            if ev.key==pygame.K_ESCAPE:
                if state=='play':state='pause';save()
                else:state='menu'
        elif ev.type==pygame.FINGERDOWN:
            pos=finger(ev);touches[('f',ev.finger_id)]=pos;tap(pos)
        elif ev.type==pygame.FINGERMOTION:touches[('f',ev.finger_id)]=finger(ev)
        elif ev.type==pygame.FINGERUP:touches.pop(('f',ev.finger_id),None)
        elif ev.type==pygame.MOUSEBUTTONDOWN:
            mouse=True;pos=convert(ev.pos);touches['mouse']=pos;tap(pos)
        elif ev.type==pygame.MOUSEMOTION and mouse:touches['mouse']=convert(ev.pos)
        elif ev.type==pygame.MOUSEBUTTONUP:mouse=False;touches.pop('mouse',None)
    if state=='play':
        a,b,j=get_buttons();a=a or ('left' in web_held);b=b or ('right' in web_held);j=j or ('jump' in web_held);moving=a or b
        shoot=any(fire_btn.collidepoint(p) for p in touches.values()) or pygame.key.get_pressed()[pygame.K_f] or ('fire' in web_held)
        if a:facing=-1
        if b:facing=1
        speed=8 if boost>0 else 5
        if fire_cooldown>0:fire_cooldown-=1
        if shoot and fire_timer>0 and fire_cooldown==0 and len(fireballs)<4:
            fireballs.append({'x':player.centerx+facing*22,'y':player.centery,'vx':facing*12,'life':65})
            fire_cooldown=13;play('jump')
        if a:player.x-=speed
        if b:player.x+=speed
        player.x=max(0,min(LEVEL_END-35,player.x))
        if j and not prev_jump and grounded:vy=-16.5;grounded=False;play('jump')
        prev_jump=j
        # Update moving platforms before vertical collision.
        for m in movers:
            r=m['r'];m['oldx']=r.x
            m['oldy']=r.y
            if m['vertical']:
                r.y=int(m['basey']+math.sin(frame*.028+m['phase'])*42)
            else:
                r.x=int(m['base']+math.sin(frame*.035+m['phase'])*60)
            if grounded and abs(player.bottom-m['oldy'])<5 and player.right>m['oldx'] and player.left<m['oldx']+r.w:
                player.x+=r.x-m['oldx']
                player.y+=r.y-m['oldy']
        oldbottom=player.bottom
        oldtop=player.top
        vy=min(18,vy+.78);player.y+=round(vy);grounded=False
        # Collision de la tete contre les blocs solides.
        if vy<0:
            for block in mystery_blocks:
                r=block['rect']
                if player.colliderect(r) and oldtop>=r.bottom-6:
                    player.top=r.bottom;vy=0
                    if not block['used']:
                        block['used']=True
                        score+=3;best=max(best,score);play('coin')
                        coin_pops.append({'x':r.centerx,'y':r.top-12,'age':0})
                    break
            for r in brick_blocks[:]:
                if player.colliderect(r) and oldtop>=r.bottom-6:
                    player.top=r.bottom;vy=0
                    brick_blocks.remove(r)
                    if r in platforms:platforms.remove(r)
                    for dx,dy,vx in [(-10,-10,-2),(10,-10,2),(-10,10,-3),(10,10,3)]:
                        brick_bits.append({'x':r.centerx+dx,'y':r.centery+dy,'vx':vx,'vy':-5,'age':0})
                    play('hit');break
        for p in platforms+[m['r'] for m in movers]:
            if player.colliderect(p) and vy>=0 and oldbottom<=p.top+8:
                player.bottom=p.top;vy=0;grounded=True
        if player.y>H+90:lose_life()
        for pop in coin_pops[:]:
            pop['age']+=1
            if pop['age']>32:coin_pops.remove(pop)
        for bit in brick_bits[:]:
            bit['age']+=1;bit['x']+=bit['vx'];bit['y']+=bit['vy'];bit['vy']+=0.65
            if bit['age']>30:brick_bits.remove(bit)
        if power_timer>0:
            power_timer-=1
            if player.height==53:
                feet=player.bottom;player.height=74;player.bottom=feet
        elif player.height>53:
            feet=player.bottom;player.height=53;player.bottom=feet
        if fire_timer>0:fire_timer-=1
        if star_timer>0:star_timer-=1
        if invincible>0:invincible-=1
        if shield>0:shield-=1
        if boost>0:boost-=1
        if player.x>1350:checkpoint=1300
        if player.x>2270:checkpoint=2280
        for spike in spikes:
            if player.colliderect(spike):lose_life();break
        for c in coins+secret_coins:
            if not c['taken'] and player.colliderect(pygame.Rect(c['x']-14,c['y']-17,28,34)):
                c['taken']=True;score+=1;best=max(best,score);play('coin')
                if c in secret_coins:secret_found+=1
        for item in hearts:
            if not item['taken'] and player.colliderect(pygame.Rect(item['x']-17,item['y']-17,34,34)):
                item['taken']=True;lives=min(5,lives+1);play('coin')
        for item in stars:
            if not item['taken'] and player.colliderect(pygame.Rect(item['x']-17,item['y']-17,34,34)):
                item['taken']=True;shield=450;boost=320;star_timer=300;invincible=max(invincible,300);play('coin')
        for item in mushrooms:
            if not item['taken'] and player.colliderect(pygame.Rect(item['x']-17,item['y']-19,34,36)):
                item['taken']=True;power_timer=600;shield=max(shield,600);play('coin')
                coin_pops.append({'x':item['x'],'y':item['y']-25,'age':0})
        for flower in flowers:
            if not flower['taken'] and player.colliderect(pygame.Rect(flower['x']-17,flower['y']-17,34,34)):
                flower['taken']=True;fire_timer=900;power_timer=max(power_timer,900);play('coin')
        for ball in fireballs[:]:
            ball['x']+=ball['vx'];ball['life']-=1
            if ball['life']<=0 or ball['x']<0 or ball['x']>LEVEL_END:
                fireballs.remove(ball);continue
            br=pygame.Rect(int(ball['x'])-9,int(ball['y'])-9,18,18)
            if any(br.colliderect(p) for p in platforms):
                fireballs.remove(ball);continue
            hit=False
            for enemy in enemies:
                if enemy['alive'] and br.colliderect(pygame.Rect(int(enemy['x']),int(enemy['y'])-25 if enemy['kind']==2 else int(enemy['y']),39,38)):
                    enemy['alive']=False;score+=2;best=max(best,score);hit=True;play('hit');break
            if boss is not None and boss_hp>0 and boss_cooldown==0 and br.colliderect(boss):
                boss_hp-=1;boss_cooldown=55;hit=True;play('hit')
            if hit:fireballs.remove(ball)
        for e in enemies:
            if not e['alive']:continue
            # Trois comportements : patrouille, poursuite de proximite, volant
            step=(1.1+level*.22)*e['speed']
            if e['kind']==1 and abs(player.centerx-e['x'])<230:
                e['dir']=1 if player.centerx>e['x'] else -1
                step*=1.55
            e['x']+=e['dir']*step
            if abs(e['x']-e['start'])>(110 if e['kind']==1 else 65):
                e['x']=max(e['start']-110,min(e['start']+110,e['x'])) if e['kind']==1 else e['x']
                e['dir']*=-1
            ey=e['y']+(int(math.sin(frame*.12+e['phase'])*16)-24 if e['kind']==2 else 0)
            # Les ennemis volants (kind=2) tirent lorsque le joueur approche.
            if e['kind']==2 and abs(player.centerx-e['x'])<410 and frame%95==(int(e['start'])%95) and len(enemy_shots)<10:
                direction=1 if player.centerx>e['x'] else -1
                enemy_shots.append({'x':e['x']+20,'y':ey+18,'vx':direction*4.2,'ttl':135})
            er=pygame.Rect(int(e['x']),ey,39,38)
            if player.colliderect(er):
                if vy>0 and oldbottom<=er.top+15:
                    e['alive']=False;vy=-11;score+=2;play('coin')
                else:lose_life()
        # Mise a jour et collisions des projectiles ennemis.
        for shot in enemy_shots[:]:
            shot['x']+=shot['vx'];shot['ttl']-=1
            if shot['ttl']<=0 or shot['x']<camera-50 or shot['x']>camera+W+50:
                enemy_shots.remove(shot);continue
            if player.colliderect(pygame.Rect(int(shot['x'])-7,int(shot['y'])-7,14,14)):
                lose_life();enemy_shots.remove(shot)
        if boss and boss_hp>0:
            boss_timer+=1
            if boss_timer%(100 if boss_hp==3 else 78 if boss_hp==2 else 60)==0 and abs(player.x-boss.x)<650:
                # Les attaques deviennent plus difficiles a mesure que le boss faiblit
                projectiles.append({'x':boss.x,'y':boss.y+24,'vx':-6.0,'vy':0.0})
                if boss_hp<=2:
                    projectiles.append({'x':boss.x,'y':boss.y+8,'vx':-5.2,'vy':-1.1})
            boss_cooldown=max(0,boss_cooldown-1)
            if player.colliderect(boss) and boss_cooldown==0:
                if vy>0 and oldbottom<=boss.top+17:
                    boss_hp-=1;vy=-13;boss_cooldown=55;play('hit')
                else:lose_life();boss_cooldown=60
        for pr in projectiles[:]:
            pr['x']+=pr['vx'];pr['y']+=pr.get('vy',0)
            if pr['x']<boss.x-850:projectiles.remove(pr);continue
            if player.colliderect(pygame.Rect(int(pr['x'])-9,int(pr['y'])-9,18,18)):
                lose_life();projectiles.remove(pr)
        if player.x>=LEVEL_END-110 and (boss is None or boss_hp<=0):
            play('win');best=max(best,score)
            if level<4:init_level(level+1);save()
            else:state='victory';save()
        camera=max(0,min(LEVEL_END-W,player.centerx-W*.37))
        draw_world()
    elif state=='menu':draw_menu()
    else:
        if state in ('pause','gameover','victory'):draw_world()
        else:draw_menu()
        if state=='pause':draw_modal('PAUSE',['REPRENDRE','RECOMMENCER','MENU PRINCIPAL'])
        elif state=='options':draw_modal('OPTIONS',['SON : '+('OUI' if sound else 'NON'),'RETOUR'])
        elif state=='scores':draw_modal('RECORD : '+str(best),['RETOUR'])
        elif state=='gameover':draw_modal('PERDU !',['REJOUER','MENU PRINCIPAL'])
        elif state=='victory':draw_modal('BRAVO !',['REJOUER','MENU PRINCIPAL'])
    # FPS diagnostic overlay (updated only a few times per second).
    if frame % 12 == 0:
        fps_label=small.render('FPS : %d' % round(clock.get_fps()),True,(220,30,30))
    if fps_label is not None:
        canvas.blit(fps_label,(W-fps_label.get_width()-20,80))
    screen.blit(canvas,(0,0))
    pygame.display.flip()
    clock.tick(30)
    await asyncio.sleep(0)
 pygame.quit()

asyncio.run(main())
